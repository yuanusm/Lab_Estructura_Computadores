/*
 * interrupciones.c
 *
 *  Created on: 5 oct 2026
 *      Author: Saile
 */

#include "interrupciones.h"
#include "tim.h"

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM6)
    {
    	flag_escribir_uart = 1;

    }
}
