/*
 * interrupciones.h
 *
 *  Created on: 5 oct 2026
 *      Author: Saile
 */

#ifndef INC_INTERRUPCIONES_H_
#define INC_INTERRUPCIONES_H_

#include "main.h"
extern uint8_t flag_escribir_uart;

#endif /* INC_INTERRUPCIONES_H_ */
